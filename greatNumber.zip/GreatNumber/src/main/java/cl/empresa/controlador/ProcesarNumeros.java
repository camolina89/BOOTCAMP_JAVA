package cl.empresa.controlador;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ProcesarNumeros
 */
@WebServlet("/ProcesarNumeros")
public class ProcesarNumeros extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public int veces = 3;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//instanciamos la sesion
		HttpSession sesion = request.getSession();
		
		//se obtiene el parametro desde el input del index.jsp
		String numero = request.getParameter("numero");
		
		Integer numeroSesion = (Integer) sesion.getAttribute("numSesion");
		
		if (sesion.getAttribute("numSesion") == null) {
			int random = (int) Math.floor(Math.random() * 100 + 1);
			
			//pasar los datos del random al atributo de la sesion.
			sesion.setAttribute("numSesion", random);
			numeroSesion = random;
			System.out.println(random);
		}
		String mensaje = "";
		String acierta = "";
		
		if (numero != null) {
			int numComparado = Integer.parseInt(numero);
			if (numeroSesion.equals(numComparado)) {
				mensaje = numero + " Encontraste el N�mero";
				veces = 3;
				acierta = "ok";
				
			}
			if (numComparado  > numeroSesion) {
				mensaje = "Too High";
				if (veces >= 1) {
					veces --;
				} 
				if (veces == 0) {
					mensaje = "Se acabaron los intentos";
					veces = 3;
				}
				
			}
			if (numComparado < numeroSesion) {
				mensaje = "Too Low";
				if (veces >= 1) {
					veces --;
				} 
				if (veces == 0) {
					mensaje = "Se acabaron los intentos";					
					veces = 3;
				}
			}
		}
		
		request.setAttribute("mensaje", mensaje);
		request.setAttribute("acierta", acierta);
		request.setAttribute("numSesion", sesion);
		request.setAttribute("veces", veces);
		
		// Obtiene la ruta de direccion
		RequestDispatcher view = request.getRequestDispatcher("index.jsp");
		//se redirige a la ruta
		view.forward(request, response);
		
	}

}
